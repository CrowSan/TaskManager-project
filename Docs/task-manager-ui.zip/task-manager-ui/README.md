# Task manager UI

A Pen created on CodePen.io. Original URL: [https://codepen.io/icebob/pen/bGpgGQ](https://codepen.io/icebob/pen/bGpgGQ).

