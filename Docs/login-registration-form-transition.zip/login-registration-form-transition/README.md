# Login/Registration Form Transition

A Pen created on CodePen.io. Original URL: [https://codepen.io/suez/pen/RpNXOR](https://codepen.io/suez/pen/RpNXOR).

Based on Dribbble shot by Barbara Morrigan - https://dribbble.com/shots/3306190-Login-Registration-form